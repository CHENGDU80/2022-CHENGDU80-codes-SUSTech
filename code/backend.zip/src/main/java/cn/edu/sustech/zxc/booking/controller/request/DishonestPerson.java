package cn.edu.sustech.zxc.booking.controller.request;

public class DishonestPerson {
    private String username;

    private int times;

    public int getTimes() {
        return times;
    }

    public void setTimes(int times) {
        this.times = times;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
