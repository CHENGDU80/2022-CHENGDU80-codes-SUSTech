<template>
	<router-view />
</template>

<style>
@import './assets/css/main.css';
@import './assets/css/color-dark.css';
</style>
