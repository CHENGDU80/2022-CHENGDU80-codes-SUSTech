<template>
	<div style="">
		<img src="../assets/img/us1.png" style="width:100%;">
		<img src="../assets/img/us2.png" style="width:100%;">
		<img src="../assets/img/us3.png" style="width:100%;">
		<img src="../assets/img/us4.png" style="width:100%;">
		<img src="../assets/img/us5.png" style="width:100%;">
	</div>
</template>

<script setup lang="ts" name="donate"></script>

<style></style>
